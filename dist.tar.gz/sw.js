/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b1bafff1'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "szmc-logo.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "pwa-512x512.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1a72911cf10faa9895cba899c9005f49"
  }, {
    "url": "ndc-logo.svg",
    "revision": "44d4e2ed2b51d3dda0b0471654fcca39"
  }, {
    "url": "ndc-logo.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "manifest.webmanifest",
    "revision": "3ee4d703e7ae7a09e3ad8d8f1c3f311d"
  }, {
    "url": "index.html",
    "revision": "d8d3237ecb6e2b672ce75c5abe83493d"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "1a72911cf10faa9895cba899c9005f49"
  }, {
    "url": "assets/vendor-supabase-B12s50R_.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-DVtotXct.js",
    "revision": null
  }, {
    "url": "assets/vendor-motion-CoNex9dD.js",
    "revision": null
  }, {
    "url": "assets/vendor-leaflet-LnAY-_sN.js",
    "revision": null
  }, {
    "url": "assets/vendor-icons-CtjlFDOW.js",
    "revision": null
  }, {
    "url": "assets/index-Dp2gkYpk.js",
    "revision": null
  }, {
    "url": "assets/index-B2vFqEee.css",
    "revision": null
  }, {
    "url": "assets/VerificationCenterModal-Boyd3WOu.js",
    "revision": null
  }, {
    "url": "assets/UpcomingFeatureView-Cw3Lshua.js",
    "revision": null
  }, {
    "url": "assets/SavedPostsView-BeSH016l.js",
    "revision": null
  }, {
    "url": "assets/ProfileView-DHUzmjWK.js",
    "revision": null
  }, {
    "url": "assets/MapView-C8Iv72vG.js",
    "revision": null
  }, {
    "url": "assets/GalleryView-79xAwxxt.js",
    "revision": null
  }, {
    "url": "assets/DirectoryView-OPGBW9SQ.js",
    "revision": null
  }, {
    "url": "assets/ContactUsView-Dblt9dIp.js",
    "revision": null
  }, {
    "url": "assets/BloodNetworkView-CnXElmz_.js",
    "revision": null
  }, {
    "url": "assets/BloodDonorRegistration-Bs6UyW8p.js",
    "revision": null
  }, {
    "url": "assets/BatchesView-BCW_OVVS.js",
    "revision": null
  }, {
    "url": "assets/AlumniDirectoryView-CJJcQsGa.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "1a72911cf10faa9895cba899c9005f49"
  }, {
    "url": "ndc-logo.jpg",
    "revision": "964365e0f5a3f9de3fe05c16429d9eb2"
  }, {
    "url": "ndc-logo.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "ndc-logo.svg",
    "revision": "44d4e2ed2b51d3dda0b0471654fcca39"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1a72911cf10faa9895cba899c9005f49"
  }, {
    "url": "pwa-512x512.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "53ec0765cf75bc9bc4dc1a36d0d34810"
  }, {
    "url": "manifest.webmanifest",
    "revision": "3ee4d703e7ae7a09e3ad8d8f1c3f311d"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 20,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/images\.unsplash\.com\/.*/i, new workbox.StaleWhileRevalidate({
    "cacheName": "unsplash-images-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 100,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/[abc]\.tile\.openstreetmap\.org\/.*/i, new workbox.CacheFirst({
    "cacheName": "map-tiles-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 200,
      maxAgeSeconds: 1209600
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
